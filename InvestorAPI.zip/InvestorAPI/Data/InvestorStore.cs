﻿using InvestorAPI.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;


namespace InvestorAPI.Data
{
    //We can use DBcontext and DBSet if we connect to the External Database like SQL server.
    public static class InvestorDataStore
    {
        public static List<Investor> Investors = new List<Investor>
    {
        new Investor
        {
            Name = "Keely Newman",
            Phone = "1-786-738-4711",
            Email = "in.magna@yahoo.com",
            Country = "USA",
            Funds = new List<string> { "Mauris LLP", "Nullam Velit Fund" }
        },
        new Investor
        {
            Name = "Kimberly Maldonado",
            Phone = "(684) 842-2371",
            Email = "non.lacinia@outlook.org",
            Country = "Spain",
            Funds = new List<string> { "Nullam Velit Fund" }
        },
        new Investor
        {
            Name = "Sean Massey",
            Phone = "(548) 250-4693",
            Email = "pharetra.quisque.ac@outlook.edu",
            Country = "Ireland",
            Funds = new List<string> { "Mauris LLP", "Ligula Aenean Fund", "Mauris Sit Amet Fund" }
        },
        new Investor
        {
            Name = "Nyssa Barr",
            Phone = "(673) 581-3597",
            Email = "odio@aol.couk",
            Country = "Canada",
            Funds = new List<string> { "Ullamcorper Viverra Fund" }
        }
    };
    }
}
