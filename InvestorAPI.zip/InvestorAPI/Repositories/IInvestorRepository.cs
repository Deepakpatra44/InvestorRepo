﻿using InvestorAPI.Model;

namespace InvestorAPI.Repositories
{
    public interface IInvestorRepository
    {
        IEnumerable<Investor> GetAll();
        Investor GetByName(string name);
        void AddInvestor(Investor investor);
        bool AddFundToInvestor(string name, string fund);
        bool DeleteInvestor(string name);
    }
}
