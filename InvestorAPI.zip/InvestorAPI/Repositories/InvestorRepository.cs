﻿using InvestorAPI.Data;
using InvestorAPI.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;


namespace InvestorAPI.Repositories
{
    public class InvestorRepository : IInvestorRepository
    {
        public IEnumerable<Investor> GetAll()
        {
           return InvestorDataStore.Investors; 
        }

        public Investor GetByName(string name)
        {
           return InvestorDataStore.Investors.FirstOrDefault(i => i.Name.Equals(name, StringComparison.OrdinalIgnoreCase));
        }
        public void AddInvestor(Investor investor)
        {
            InvestorDataStore.Investors.Add(investor);
        }

        public bool AddFundToInvestor(string name, string fund)
        {
            var investor = GetByName(name);
            if (investor == null || investor.Funds.Contains(fund))
                return false;
            investor.Funds.Add(fund);
            return true;
        }

        public bool DeleteInvestor(string name)
        {
            var investor = GetByName(name);
            if (investor == null)
                return false;
            InvestorDataStore.Investors.Remove(investor);
            return true;
        }
    }
}
