﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using InvestorAPI.Model;
using InvestorAPI.Repositories;

namespace InvestorAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InvestorsController : ControllerBase
    {
        private readonly IInvestorRepository _repository;

        public InvestorsController(IInvestorRepository repository)
        {
            _repository = repository;
        }
        //Task 1 Return all investors
        [HttpGet]
        public IActionResult GetAll()
        {
            try
            {
                return Ok(_repository.GetAll());
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }
        //Task 2 Return single investor by name
        [HttpGet("{name}")]
        public IActionResult GetByName(string name)
        {
            try
            {
                var investor = _repository.GetByName(name);
                return investor == null ? NotFound() : Ok(investor);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        //Task 3 Add fund to investor
        [HttpPut("{name}/addfund")]
        public IActionResult AddFund(string name, [FromQuery] string fund)
        {
            try
            {
                var added = _repository.AddFundToInvestor(name, fund);
                return added ? Ok("Fund added.") : NotFound("Investor not found or fund already exists.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        //Task 4 Add new investor

        [HttpPost]
        public IActionResult AddInvestor([FromBody] Investor investor)
        {
            try
            {
                _repository.AddInvestor(investor);
                return Ok("Investor added successfully.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }
        //Task 5 Delete investor
        [HttpDelete("{name}")]
        public IActionResult DeleteInvestor(string name)
        {
            try
            {
                var deleted = _repository.DeleteInvestor(name);
                return deleted ? Ok("Investor deleted.") : NotFound("Investor not found.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }
    }
}
